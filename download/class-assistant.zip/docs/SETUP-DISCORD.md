# 🎮 Discord Setup Guide

Connect your AI assistant to Discord. Great for multi-agent setups — one channel per agent!

## Why Discord for Multi-Agent?

- **Free** — no limits on channels or bots
- **One channel per agent** — clean separation (e.g., #general, #developer, #analyst)
- **Thread support** — keeps conversations organized
- **Works on all devices** — desktop, mobile, web
- **Group access** — invite friends/team to your AI server

## Step 1: Create a Discord Server (1 minute)

1. Open Discord (https://discord.com or the app)
2. Click the **+** button on the left sidebar
3. Choose **"Create My Own"**
4. Choose **"For me and my friends"**
5. Name it something like: **"AI Assistant"** or **"My Agents"**
6. Click **Create**

### Create channels for each agent:
1. Click the **+** next to "TEXT CHANNELS"
2. Create these channels:

| Channel Name | Agent | Purpose |
|-------------|-------|---------|
| `#general` | General | Daily chat, quick questions |
| `#analyst` | Analyst | Deep thinking, research |
| `#developer` | Developer | Coding, software |
| `#engineer` | Engineer | Hardware, technical |
| `#finance` | Finance | Money, budgets |

## Step 2: Create a Discord Bot (3 minutes)

1. Go to **https://discord.com/developers/applications**
2. Click **"New Application"**
3. Name it: **"AI Assistant"** (or whatever you like)
4. Click **Create**

### Get the Bot Token:
1. Click **"Bot"** in the left menu
2. Click **"Reset Token"**
3. **Copy the token** — you'll need it!
   ```
   Looks like: MTIzNDU2Nzg5MDEyMzQ1Njc4.ABCdef.xxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
   ⚠️ **Keep this secret! Don't share it publicly.**

### Set Bot Permissions:
1. Still on the Bot page, scroll down to **"Privileged Gateway Intents"**
2. Enable:
   - ✅ **Message Content Intent** (required — bot needs to read messages)
   - ✅ **Server Members Intent** (optional)
3. Click **Save Changes**

## Step 3: Invite the Bot to Your Server

1. Click **"OAuth2"** in the left menu
2. Click **"URL Generator"**
3. Under **Scopes**, check:
   - ✅ `bot`
   - ✅ `applications.commands`
4. Under **Bot Permissions**, check:
   - ✅ Send Messages
   - ✅ Read Message History
   - ✅ Embed Links
   - ✅ Attach Files
   - ✅ Use Slash Commands
   - ✅ Add Reactions
   - ✅ Manage Threads
   - ✅ Send Messages in Threads
5. Copy the **Generated URL** at the bottom
6. Open it in your browser
7. Select your server → **Authorize**

Your bot should now appear in your server! (it will be offline until we configure OpenClaw)

## Step 4: Configure OpenClaw

```bash
openclaw configure --section channels
```

Select **Discord**, then paste your bot token.

**Or set it directly:**
```bash
openclaw config set channels.discord.token "YOUR_BOT_TOKEN_HERE"
```

### Multi-Agent Channel Routing

To route each Discord channel to a specific agent, add this to your `~/.openclaw/openclaw.json`:

```json5
{
  "channels": {
    "discord": {
      "token": "YOUR_BOT_TOKEN",
      "groups": {
        "CHANNEL_ID_FOR_GENERAL": { "agentId": "general" },
        "CHANNEL_ID_FOR_ANALYST": { "agentId": "analyst" },
        "CHANNEL_ID_FOR_DEVELOPER": { "agentId": "developer" },
        "CHANNEL_ID_FOR_ENGINEER": { "agentId": "engineer" },
        "CHANNEL_ID_FOR_FINANCE": { "agentId": "finance" }
      }
    }
  }
}
```

### How to Get Channel IDs:
1. In Discord, go to **User Settings → Advanced**
2. Enable **Developer Mode**
3. Right-click any channel → **Copy Channel ID**

## Step 5: Start and Test

```bash
openclaw gateway restart
```

Go to your Discord server and type a message in `#general`. Your AI assistant should reply! 🎉

Then try `#developer` — that agent should respond with its coding personality.

## Multi-Agent Setup (20+ Agents)

Discord is ideal for large agent setups:

### Organize with Categories:
```
📁 MAIN
  #general
  #announcements

📁 SPECIALISTS  
  #analyst
  #developer
  #engineer
  #finance

📁 PROJECTS
  #project-alpha
  #project-beta
```

### Tips for Many Agents:
- **One bot** can serve all channels (route by channel ID)
- **Categories** keep channels organized
- **Threads** for long conversations within a channel
- **Pinned messages** for agent capabilities/instructions
- **Roles** to control who can access which agent channels

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Bot is offline | Check: `openclaw gateway status` |
| Bot doesn't respond | Make sure **Message Content Intent** is enabled |
| Bot responds in wrong channel | Check channel ID routing in config |
| "Missing Access" error | Re-invite bot with correct permissions |
| Bot responds to itself | Normal — OpenClaw filters self-messages |
| Rate limited | Discord limits: 5 messages/5 seconds per channel |

## Quick Reference

| What | Where |
|------|-------|
| Create bot | https://discord.com/developers/applications |
| Bot token | Developer Portal → Your App → Bot → Token |
| Channel IDs | Right-click channel (Developer Mode ON) |
| OpenClaw config | `~/.openclaw/openclaw.json` |
| Restart | `openclaw gateway restart` |
| Logs | `openclaw logs` |
