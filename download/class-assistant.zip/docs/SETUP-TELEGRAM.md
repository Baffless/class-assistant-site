# 📱 Telegram Bot Setup Guide

Connect your AI assistant to Telegram so you can chat from anywhere.

## Step 1: Create a Telegram Bot (2 minutes)

1. Open Telegram on your phone or computer
2. Search for **@BotFather** (official Telegram bot creator)
3. Send: `/newbot`
4. BotFather asks: **"What name for your bot?"**
   - Type a friendly name, e.g.: `My AI Assistant`
5. BotFather asks: **"Choose a username"**
   - Must end in `bot`, e.g.: `myai_helper_bot`
   - Must be unique — try adding numbers if taken
6. **BotFather gives you an API token** that looks like:
   ```
   7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
   ⚠️ **Copy this token! You'll need it in the next step.**

## Step 2: Configure OpenClaw with the Token

Run this command and paste your token when asked:

```bash
openclaw configure --section channels
```

Select **Telegram**, then paste your bot token.

**Or set it directly:**
```bash
openclaw config set channels.telegram.token "YOUR_BOT_TOKEN_HERE"
```

## Step 3: Start Chatting!

1. Restart the gateway:
   ```bash
   openclaw gateway restart
   ```
2. Open Telegram
3. Search for your bot's username (e.g., `@myai_helper_bot`)
4. Press **Start** or send any message
5. Your AI assistant will reply! 🎉

## Optional: Make It Private

By default, anyone who finds your bot can message it. To restrict it:

```bash
# Only allow your Telegram user ID
openclaw config set channels.telegram.allowedUsers '["YOUR_TELEGRAM_USER_ID"]'
```

To find your Telegram user ID:
1. Search for **@userinfobot** on Telegram
2. Send it any message
3. It replies with your user ID (a number like `123456789`)

## Optional: Bot Profile Photo

1. Go to @BotFather
2. Send: `/setuserpic`
3. Choose your bot
4. Send a photo — this becomes your bot's avatar!

## Optional: Bot Description

1. Go to @BotFather
2. Send: `/setdescription`
3. Choose your bot
4. Type a description, e.g.: "AI assistant powered by Claude"

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Bot doesn't respond | Check: `openclaw gateway status` — is it running? |
| "Unauthorized" error | Token is wrong. Get a new one from @BotFather |
| Bot responds slowly | Normal on first message. Should be faster after |
| Multiple bots | You can create multiple bots for different agents |
| Bot in groups | Send `/setjoingroups` to @BotFather to enable |

## Group Chat Setup (Optional)

If you want your bot in a Telegram group:

1. Tell @BotFather: `/setjoingroups` → Enable
2. Tell @BotFather: `/setprivacy` → Disable (so bot sees all messages)
3. Add the bot to your group
4. The bot will respond when mentioned or to all messages (configurable)
