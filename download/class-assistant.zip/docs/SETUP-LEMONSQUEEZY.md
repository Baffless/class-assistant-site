# 💰 Lemonsqueezy Store Setup

Sell Class Assistant for €10 with automatic license keys. Zero manual work per sale.

## Step 1: Create Lemonsqueezy Account

1. Go to **https://lemonsqueezy.com**
2. Click **Get Started**
3. Sign up with email
4. **Store name**: `classassistant` (or your choice)
5. **Store URL will be**: `classassistant.lemonsqueezy.com`

## Step 2: Get Paid (Connect Bank)

1. Go to **Settings → Payouts**
2. Add your **bank account (IBAN)**
   - Use your **Revolut IBAN**
   - Found in Revolut app → EUR account → Account details
3. Complete identity verification (required by law)

**Payout schedule**: Weekly or monthly (you choose)

## Step 3: Create the Product

1. Go to **Products → + New Product**
2. Fill in:

| Field | Value |
|-------|-------|
| **Name** | Class Assistant — AI Teaching Assistant |
| **Description** | (see below) |
| **Price** | €10 (one-time) |
| **Type** | Software / Digital Product |
| **Files** | Upload `ClassAssistant.zip` (the installer package) |

### Product Description (copy this):
```
🎓 AI Teaching Assistant with Personalized Student Agents

✅ One AI agent per student — learns their strengths and weaknesses
✅ Automatically personalizes tasks for each student's level
✅ Tracks behavior, grades, and learning style over time
✅ Bilingual: English & Lithuanian (lietuvių kalba)
✅ Privacy-first: all student data stays on YOUR computer
✅ Works on Windows, Mac, and Linux
✅ Discord integration: one channel per student

What you get:
• Full installer with license key
• Teacher Assistant AI agent
• Individual student agents (unlimited students)
• Auto-start on boot
• Desktop shortcut for instant access
• Network sharing for easy file access

Requirements:
• Claude ($20/mo) or ChatGPT ($20/mo) subscription
• Windows 10+, macOS, or Linux computer
• Internet connection
```

## Step 4: Enable License Keys (THE KEY PART!)

1. Still on the product page, scroll to **License Keys**
2. **Enable**: ✅ Generate a license key for this product
3. Settings:
   - **Activation limit**: `1` (one computer per license)
   - **Key prefix**: `CA-` (optional, looks nice)
4. **Save**

That's it! Lemonsqueezy now:
- Auto-generates a unique license key per buyer
- Buyer sees the key in their purchase confirmation email
- Your installer validates the key via Lemonsqueezy API
- Key locks to one machine on first install

## Step 5: Build the Download Package

On your Pi, run:
```bash
cd ~/class-assistant/tools
./build-download.sh
```

This creates `dist/ClassAssistant.zip` — upload this to Lemonsqueezy as the product file.

**Note**: Since Lemonsqueezy handles license keys, all buyers get the same ZIP. The license key comes separately in their email.

## Step 6: Publish & Share

1. Click **Publish** on your product
2. Your checkout URL: `https://classassistant.lemonsqueezy.com/checkout/buy/YOUR_VARIANT_ID`
3. Share this link everywhere!

## How It Works (Buyer Flow)

```
Teacher → Clicks your link
       → Pays €10 (card/PayPal/Apple Pay)
       → Gets email with:
           • Download link for ClassAssistant.zip
           • Unique license key: CA-XXXXXXXX-XXXX-XXXX...
       → Downloads ZIP
       → Double-clicks installer
       → Enters license key when asked
       → Key validated + locked to their computer
       → Everything installs automatically
       → Browser opens → start chatting!
```

## Fee Summary

| | Amount |
|---|-------|
| Price | €10.00 |
| Lemonsqueezy fee (5% + €0.50) | -€1.00 |
| **You receive** | **€9.00** |

## Dashboard

Track everything at `app.lemonsqueezy.com`:
- 💰 Revenue & sales
- 🔑 All license keys issued
- 👥 Customer list
- 📊 Analytics
- 🔄 Refunds (if needed)

## Updating the Product

When you improve Class Assistant:
1. Build new ZIP: `./build-download.sh`
2. Go to product → Files → Upload new version
3. Existing buyers get notified of update

## Lithuanian Product Page (Optional)

You can create a second variant in Lithuanian:
1. Product → Add Variant
2. Same price, but Lithuanian name/description
3. Separate checkout URL for LT audience
