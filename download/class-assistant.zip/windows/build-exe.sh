#!/usr/bin/env bash
# Build a self-extracting Windows installer
# Run this on any Linux/Mac to create the .exe-like package

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Install makeself if not present
if ! command -v makeself &>/dev/null; then
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y makeself
    else
        echo "Please install makeself first"
        exit 1
    fi
fi

# Create temp directory with all needed files
TMPDIR=$(mktemp -d)
cp "$PROJECT_DIR/install.sh" "$TMPDIR/"
cp -r "$PROJECT_DIR/agents" "$TMPDIR/"
cp "$SCRIPT_DIR/install-windows.bat" "$TMPDIR/"

# Create the launcher that Windows will run
cat > "$TMPDIR/setup.bat" << 'SETUPEOF'
@echo off
title Class Assistant Setup
echo Starting Class Assistant installer...
call install-windows.bat
SETUPEOF

# Build self-extracting archive
makeself "$TMPDIR" "$PROJECT_DIR/ClassAssistant-Setup.sh" \
    "Class Assistant - AI Teaching Assistant" \
    ./install.sh

rm -rf "$TMPDIR"

echo "✅ Self-extracting installer created: ClassAssistant-Setup.sh"
echo "   For Windows users, distribute install-windows.bat + install-wsl.sh"
echo "   For Linux/Mac users, distribute ClassAssistant-Setup.sh"
