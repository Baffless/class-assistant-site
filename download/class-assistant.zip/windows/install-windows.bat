@echo off
setlocal EnableDelayedExpansion
title Class Assistant - Setup / Diegimas
color 0B
chcp 65001 >nul 2>&1

echo.
echo   ======================================================
echo   ^|  🎓 Class Assistant - AI Teaching Assistant         ^|
echo   ^|  AI Mokytojo Asistentas                             ^|
echo   ======================================================
echo.
echo   This will set up everything automatically.
echo   Tai viską automatiškai įdiegs.
echo.
echo   Press any key to begin / Spauskite bet kurį mygtuką...
pause >nul

echo.
echo [1/3] Checking WSL2...
wsl --status >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo        Installing WSL2...
    echo        Your computer will RESTART after this step.
    echo        Jūsų kompiuteris bus PALEISTAS IŠ NAUJO.
    echo.
    pause
    wsl --install -d Ubuntu
    echo.
    echo   WSL2 installed! Please RESTART your PC.
    echo   Then run this installer again.
    pause
    exit /b
)

echo        WSL2 ready!

echo.
echo [2/3] Installing Class Assistant...
wsl -d Ubuntu -- bash -c "curl -fsSL https://raw.githubusercontent.com/Baffless/class-assistant/main/install-wsl.sh | bash"

echo.
echo [3/3] Creating shortcuts...
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
(
    echo Set ws = CreateObject^("Wscript.Shell"^)
    echo ws.Run "wsl -d Ubuntu -- bash -c 'openclaw gateway start'", 0
) > "%STARTUP%\class-assistant-autostart.vbs"

set "DESKTOP=%USERPROFILE%\Desktop"
(
    echo Set ws = CreateObject^("Wscript.Shell"^)
    echo ws.Run "cmd /c start http://localhost:18789", 0
) > "%DESKTOP%\Class Assistant.vbs"

echo.
echo   =============================================
echo   ^|  🎉 Done! / Baigta!                      ^|
echo   ^|  Double-click "Class Assistant" on desktop ^|
echo   =============================================
echo.
pause
