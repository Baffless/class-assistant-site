# 🎓 Class Assistant — AI Teaching Assistant

> Personalized AI assistant for every student in your class.
> Individualizuotas AI asistentas kiekvienam mokiniui klasėje.

## What Is This?

Class Assistant gives you a personal AI teaching assistant that **knows every student individually**. It tracks their strengths, weaknesses, and learning style — then **personalizes tasks automatically** for each student.

### How It Works

```
Teacher: "Create a math quiz for the class"

→ Jonas (strong at math): Gets challenging problems
→ Ona (visual learner): Gets problems with diagrams
→ Petras (needs practice): Gets extra guided examples
→ Marija (advanced): Gets bonus challenge questions
```

**Each student has their own AI agent** that builds a learning profile over time. The more you use it, the smarter it gets about your students.

## 🔒 Privacy First

- **All student data stays on YOUR computer** — never uploaded
- The AI cloud only sees your questions, not stored profiles
- No one else can access student information
- You own and control everything

## Features

- 🎯 **Personalized tasks** — automatically adapted per student
- 📊 **Class overview** — see who's improving, who needs help
- 📝 **Lesson planning** — with built-in differentiation
- 👨‍👩‍👧 **Parent communication** — draft emails and reports
- 🌍 **Bilingual** — English and Lithuanian (lietuvių kalba)
- 🎮 **Discord channels** — optional, one channel per student
- 📈 **Learns over time** — profiles improve with every interaction

## Installation

### Linux / Raspberry Pi / Mac
```bash
curl -fsSL https://raw.githubusercontent.com/Baffless/class-assistant/main/install.sh | bash
```

### Windows
Download and double-click `install-windows.bat`

### What Happens During Install
1. Choose language (English / Lietuvių)
2. Paste your AI cloud key (Claude or ChatGPT)
3. Select student age group
4. Type all student names
5. **Done!** Browser opens, start chatting with your assistant

## 💰 Pricing

- **Class Assistant**: €10 one-time purchase → [Buy here](https://classassistant.lemonsqueezy.com)
- **AI Cloud Service**: You pay your own subscription
  - Claude Pro: $20/month (recommended)
  - ChatGPT Plus: $20/month

## Requirements

- Computer running Windows 10+, macOS, or Linux
- Internet connection (for AI cloud service)
- Claude or ChatGPT subscription ($20/month)

## Customization

After installation, find `~/Agent Folder` on your computer:

```
Agent Folder/
├── Teacher Assistant/    ← Main assistant settings
│   ├── SOUL.md          ← Personality & capabilities
│   └── MEMORY.md        ← Class knowledge
├── Jonas/               ← Student agent
│   ├── SOUL.md          ← Learning profile
│   └── MEMORY.md        ← Observations & progress
├── Ona/
├── Petras/
└── ...
```

Edit `MEMORY.md` files to add notes about students. The AI reads these to personalize everything.

## Support

- 📖 [Telegram Setup](docs/SETUP-TELEGRAM.md)
- 🎮 [Discord Setup](docs/SETUP-DISCORD.md)
- 📧 Questions? Open an issue on GitHub

## License

MIT License — free to use, modify, and distribute.

---

Made with ❤️ for teachers / Sukurta su ❤️ mokytojams
