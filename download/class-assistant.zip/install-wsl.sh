#!/usr/bin/env bash
set -e
echo "🎓 Setting up Class Assistant inside WSL..."
sudo apt-get update -qq
sudo apt-get install -y git curl
if ! command -v node &>/dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi
if ! command -v openclaw &>/dev/null; then
    sudo npm install -g openclaw
fi
cd ~
if [ ! -d "class-assistant" ]; then
    git clone https://github.com/Baffless/class-assistant.git
fi
cd class-assistant
chmod +x install.sh
./install.sh
