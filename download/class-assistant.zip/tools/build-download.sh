#!/usr/bin/env bash
# Build the download package for Lemonsqueezy
# License key is NOT embedded — Lemonsqueezy provides it separately

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BUILD_DIR=$(mktemp -d)
PKG_DIR="$BUILD_DIR/ClassAssistant"
OUTPUT_DIR="$PROJECT_DIR/dist"

mkdir -p "$PKG_DIR" "$OUTPUT_DIR"

echo "📦 Building Class Assistant download package..."

# Copy files
cp "$PROJECT_DIR/install.sh" "$PKG_DIR/"
cp -r "$PROJECT_DIR/agents" "$PKG_DIR/"
cp "$PROJECT_DIR/install-wsl.sh" "$PKG_DIR/"

# Mac installer
cat > "$PKG_DIR/Install - Mac.command" << 'MACEOF'
#!/usr/bin/env bash
cd "$(dirname "$0")"
echo ""
echo "🎓 Starting Class Assistant installation..."
echo ""
chmod +x install.sh
./install.sh
echo ""
echo "Press any key to close..."
read -n1
MACEOF
chmod +x "$PKG_DIR/Install - Mac.command"

# Linux installer
cat > "$PKG_DIR/Install - Linux.sh" << 'LNXEOF'
#!/usr/bin/env bash
cd "$(dirname "$0")"
echo ""
echo "🎓 Starting Class Assistant installation..."
echo ""
chmod +x install.sh
./install.sh
echo ""
echo "Press Enter to close..."
read
LNXEOF
chmod +x "$PKG_DIR/Install - Linux.sh"

# Windows installer
cp "$PROJECT_DIR/windows/install-windows.bat" "$PKG_DIR/Install - Windows.bat"

# README
cat > "$PKG_DIR/README.txt" << 'READMEEOF'
============================================
🎓 Class Assistant — AI Teaching Assistant
============================================

INSTALLATION:

  Windows:  Double-click "Install - Windows.bat"
  Mac:      Double-click "Install - Mac.command"
  Linux:    Double-click "Install - Linux.sh"

  You will need the LICENSE KEY from your
  purchase confirmation email.

WHAT YOU NEED:
  • Internet connection
  • Claude ($20/mo) or ChatGPT ($20/mo) subscription
  • Your license key (from purchase email)

============================================
READMEEOF

# Build ZIP
cd "$BUILD_DIR"
zip -r "$OUTPUT_DIR/ClassAssistant.zip" ClassAssistant/
rm -rf "$BUILD_DIR"

echo ""
echo "✅ Package built: dist/ClassAssistant.zip"
echo "   Upload this to Lemonsqueezy as product file"
echo ""
ls -lh "$OUTPUT_DIR/ClassAssistant.zip"
