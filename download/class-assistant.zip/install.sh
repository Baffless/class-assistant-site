#!/usr/bin/env bash
set -e

# ============================================================
#  🎓 Class Assistant — AI Teaching Assistant
#  One-click installer for teachers
# ============================================================

VERSION="1.0.0"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

print_step()  { echo -e "  ${GREEN}✅${NC} $1"; }
print_info()  { echo -e "  ${BLUE}ℹ${NC}  $1"; }
print_warn()  { echo -e "  ${YELLOW}⚠️${NC}  $1"; }
print_error() { echo -e "  ${RED}❌${NC} $1"; }
print_ask()   { echo -ne "  ${CYAN}?${NC}  $1"; }


# ============================================================
# LICENSE KEY VALIDATION
# ============================================================
check_license() {
    OPENCLAW_DIR="$HOME/.openclaw"
    LOCK_FILE="$OPENCLAW_DIR/.license-lock"
    MACHINE_ID=$(cat /etc/machine-id 2>/dev/null || hostname | sha256sum | cut -c1-32)
    
    # Check if already activated on this machine
    if [ -f "$LOCK_FILE" ]; then
        LOCKED_MACHINE=$(head -1 "$LOCK_FILE")
        if [ "$LOCKED_MACHINE" = "$MACHINE_ID" ]; then
            print_step "License verified"
            return 0
        fi
    fi
    
    echo ""
    echo -e "  ${BOLD}━━━ 🔑 License Key ━━━${NC}"
    echo ""
    echo "  Enter your license key from the purchase email."
    echo "  Don't have one? Buy at:"
    echo "  ${CYAN}https://classassistant.lemonsqueezy.com${NC}"
    echo ""
    print_ask "License key: "
    read -r LICENSE_KEY
    
    if [ -z "$LICENSE_KEY" ]; then
        print_error "No license key entered!"
        echo "    Purchase at: https://classassistant.lemonsqueezy.com"
        exit 1
    fi
    
    # Validate against Lemonsqueezy API
    print_info "Validating license..."
    
    RESPONSE=$(curl -s -X POST "https://api.lemonsqueezy.com/v1/licenses/validate"         -H "Content-Type: application/json"         -d "{"license_key": "${LICENSE_KEY}", "instance_name": "${MACHINE_ID}"}"         2>/dev/null)
    
    # Check if validation succeeded
    VALID=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('valid', False))" 2>/dev/null)
    ERROR=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('error', ''))" 2>/dev/null)
    
    if [ "$VALID" = "True" ]; then
        # Activate the license (increment activation count)
        curl -s -X POST "https://api.lemonsqueezy.com/v1/licenses/activate"             -H "Content-Type: application/json"             -d "{"license_key": "${LICENSE_KEY}", "instance_name": "${MACHINE_ID}"}"             >/dev/null 2>&1
        
        # Save locally
        mkdir -p "$OPENCLAW_DIR"
        echo "$MACHINE_ID" > "$LOCK_FILE"
        echo "$LICENSE_KEY" >> "$LOCK_FILE"
        chmod 600 "$LOCK_FILE"
        
        print_step "License activated! ✅"
    elif echo "$ERROR" | grep -qi "limit"; then
        print_error "This license is already used on another computer."
        echo "    Each license works on ONE computer."
        echo "    Purchase another: https://classassistant.lemonsqueezy.com"
        exit 1
    else
        # If no internet, allow offline with basic format check
        if [ -z "$RESPONSE" ]; then
            print_warn "Cannot verify online (no internet). Saving for later verification."
            mkdir -p "$OPENCLAW_DIR"
            echo "$MACHINE_ID" > "$LOCK_FILE"
            echo "$LICENSE_KEY" >> "$LOCK_FILE"
            chmod 600 "$LOCK_FILE"
        else
            print_error "Invalid license key!"
            echo "    Purchase at: https://classassistant.lemonsqueezy.com"
            exit 1
        fi
    fi
}

# ============================================================
# BANNER
# ============================================================
print_banner() {
    echo ""
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════════╗"
    echo "  ║                                                  ║"
    echo "  ║   🎓 Class Assistant                             ║"
    echo "  ║   AI Teaching Assistant / AI Mokytojo Asistentas ║"
    echo "  ║                                                  ║"
    echo "  ║   v${VERSION}                                         ║"
    echo "  ╚══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ============================================================
# DETECT PLATFORM
# ============================================================
detect_platform() {
    OS="linux"
    if [ -f /proc/device-tree/model ] && grep -qi "raspberry" /proc/device-tree/model 2>/dev/null; then
        OS="rpi"
    elif [[ "$(uname)" == "Darwin" ]]; then
        OS="macos"
    elif grep -qi microsoft /proc/version 2>/dev/null; then
        OS="wsl"
    fi
}

# ============================================================
# INSTALL DEPENDENCIES
# ============================================================
ensure_nodejs() {
    if command -v node &>/dev/null; then
        print_step "Node.js $(node -v) found"
        return
    fi
    print_info "Installing Node.js..."
    if [ "$OS" = "macos" ]; then
        if command -v brew &>/dev/null; then
            brew install node
        else
            curl -fsSL https://nodejs.org/dist/v22.12.0/node-v22.12.0.pkg -o /tmp/node.pkg
            sudo installer -pkg /tmp/node.pkg -target /
        fi
    else
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    print_step "Node.js installed"
}

ensure_openclaw() {
    if command -v openclaw &>/dev/null; then
        print_step "OpenClaw $(openclaw --version 2>/dev/null || echo '') found"
        return
    fi
    print_info "Installing OpenClaw..."
    sudo npm install -g openclaw 2>/dev/null || npm install -g openclaw
    print_step "OpenClaw installed"
}

# ============================================================
# LANGUAGE SELECTION
# ============================================================
select_language() {
    echo ""
    echo -e "  ${BOLD}━━━ 🌍 Language / Kalba ━━━${NC}"
    echo ""
    echo "  1. English"
    echo "  2. Lietuvių (Lithuanian)"
    echo ""
    print_ask "Choose / Pasirinkite (1 or 2): "
    read -r LANG_CHOICE
    LANG_CHOICE="${LANG_CHOICE:-1}"
    
    if [ "$LANG_CHOICE" = "2" ]; then
        LANG="lt"
        REGION="Lithuania"
        LANG_INSTRUCTION="Always communicate in Lithuanian (lietuvių kalba). All tasks, responses, and interactions must be in Lithuanian unless the teacher specifically asks for another language."
        
        # Lithuanian UI strings
        STR_HOW_IT_WORKS="━━━ Kaip tai veikia ━━━"
        STR_CLOUD_EXPLAIN="Class Assistant yra AI mokymo asistentas, kuris veikia JŪSŲ kompiuteryje.\n  Jis jungiasi prie debesų AI paslaugos (pvz., Claude arba ChatGPT),\n  kad galėtų atsakyti į klausimus. Jums reikia mokamos prenumeratos\n  arba API rakto iš vieno iš šių tiekėjų."
        STR_CLOUD_LOCAL="☁️  AI veikia debesyje. Jūs mokate tiekėjui."
        STR_LOCAL_FREE="💻  Class Assistant veikia lokaliai. Jis nemokamas ir atviro kodo."
        STR_KEY_CONNECT="🔑  Autentifikacijos raktas sujungia jūsų kompiuterį su debesimi."
        STR_CHOOSE_CLOUD="Kurį debesų AI norite naudoti?"
        STR_RECOMMENDED="rekomenduojama"
        STR_PASTE_KEY="Įklijuokite savo raktą arba setup-token: "
        STR_NO_KEY="Raktas nepateiktas. AI raktą reikia norint naudoti asistentą."
        STR_KEY_OK="Raktas priimtas!"
        STR_SIT_BACK="Viską nustatome... atsisėskite ir atsipalaiduokite! ☕"
        STR_AGE_GROUP="━━━ 🎂 Amžiaus grupė ━━━"
        STR_AGE_ASK="Mokinių amžiaus grupė:"
        STR_AGE_1="Pradinė mokykla (6-10 metų)"
        STR_AGE_2="Pagrindinė mokykla (11-14 metų)"
        STR_AGE_3="Vidurinė mokykla (15-18 metų)"
        STR_STUDENTS="━━━ 👧👦 Mokiniai ━━━"
        STR_STUDENTS_ASK="Įveskite visų mokinių vardus.\n  Galite rašyti po vieną per eilutę arba atskirti kableliais.\n  Pavyzdys: Jonas, Ona, Petras, Marija"
        STR_STUDENTS_PROMPT="Mokinių vardai: "
        STR_STUDENTS_CONFIRM="mokiniai(-ių) rasti"
        STR_CREATING="Kuriami mokinių agentai..."
        STR_DONE="Instaliacija baigta!"
        STR_CHAT_OPEN="Pokalbis atidarytas naršyklėje!"
        STR_PRIVACY="🔒 PRIVATUMAS: Visi mokinių duomenys saugomi TIK jūsų kompiuteryje."
        STR_START="Pradėti dabar?"
    else
        LANG="en"
        REGION="International"
        LANG_INSTRUCTION="Communicate in English. Use clear, simple language appropriate for educators."
        
        STR_HOW_IT_WORKS="━━━ How It Works ━━━"
        STR_CLOUD_EXPLAIN="Class Assistant is an AI teaching assistant that runs on YOUR computer.\n  It connects to a cloud AI service (like Claude or ChatGPT)\n  to power the conversation. You need a paid subscription\n  or API key from one of these providers."
        STR_CLOUD_LOCAL="☁️  The AI runs in the cloud. You pay the provider."
        STR_LOCAL_FREE="💻  Class Assistant runs locally. It's free and open source."
        STR_KEY_CONNECT="🔑  The auth key connects your local setup to the cloud."
        STR_CHOOSE_CLOUD="Which cloud AI do you want to use?"
        STR_RECOMMENDED="recommended"
        STR_PASTE_KEY="Paste your key or setup-token: "
        STR_NO_KEY="No key provided. You need an auth key to use the AI."
        STR_KEY_OK="Key received!"
        STR_SIT_BACK="Setting everything up... sit back and relax! ☕"
        STR_AGE_GROUP="━━━ 🎂 Age Group ━━━"
        STR_AGE_ASK="Student age group:"
        STR_AGE_1="Primary school (ages 6-10)"
        STR_AGE_2="Middle school (ages 11-14)"
        STR_AGE_3="High school (ages 15-18)"
        STR_STUDENTS="━━━ 👧👦 Students ━━━"
        STR_STUDENTS_ASK="Enter all student names.\n  One per line, or separated by commas.\n  Example: John, Emma, Lucas, Sofia"
        STR_STUDENTS_PROMPT="Student names: "
        STR_STUDENTS_CONFIRM="student(s) found"
        STR_CREATING="Creating student agents..."
        STR_DONE="Installation Complete!"
        STR_CHAT_OPEN="Chat is open in your browser!"
        STR_PRIVACY="🔒 PRIVACY: All student data is stored ONLY on your computer."
        STR_START="Start now?"
    fi
}

# ============================================================
# CLOUD AUTH
# ============================================================
configure_cloud() {
    echo ""
    echo -e "  ${BOLD}${STR_HOW_IT_WORKS}${NC}"
    echo ""
    echo -e "  ${STR_CLOUD_EXPLAIN}"
    echo ""
    echo -e "  ${BOLD}${STR_CLOUD_LOCAL}${NC}"
    echo -e "  ${BOLD}${STR_LOCAL_FREE}${NC}"
    echo -e "  ${BOLD}${STR_KEY_CONNECT}${NC}"
    echo ""
    echo -e "  ┌─────────────────────────────────────────────────────┐"
    echo -e "  │  ${BOLD}${STR_CHOOSE_CLOUD}${NC}"
    echo -e "  │                                                     │"
    echo -e "  │  ${CYAN}1.${NC} Claude (Anthropic) — ${BOLD}${STR_RECOMMENDED}${NC}"
    echo -e "  │     \$20/mo Pro or \$100-200/mo Max                  │"
    echo -e "  │                                                     │"
    echo -e "  │  ${CYAN}2.${NC} ChatGPT (OpenAI)                                │"
    echo -e "  │     \$20/mo Plus or pay-per-token                   │"
    echo -e "  └─────────────────────────────────────────────────────┘"
    echo ""
    print_ask "Choose (1 or 2): "
    read -r CLOUD_CHOICE
    CLOUD_CHOICE="${CLOUD_CHOICE:-1}"
    
    echo ""
    
    if [ "$CLOUD_CHOICE" = "2" ]; then
        MODEL_PROVIDER="openai"
        AUTH_MODE="api-key"
        if [ "$LANG" = "lt" ]; then
            echo -e "  ${BOLD}Kaip gauti OpenAI API raktą:${NC}"
            echo ""
            echo "  1. Eikite į: ${CYAN}https://platform.openai.com/api-keys${NC}"
            echo "  2. Prisijunkite su savo OpenAI/ChatGPT paskyra"
            echo "  3. Spauskite '+ Create new secret key'"
            echo "  4. Nukopijuokite raktą (prasideda sk-...)"
        else
            echo -e "  ${BOLD}How to get your OpenAI API key:${NC}"
            echo ""
            echo "  1. Go to: ${CYAN}https://platform.openai.com/api-keys${NC}"
            echo "  2. Sign in with your OpenAI/ChatGPT account"
            echo "  3. Click '+ Create new secret key'"
            echo "  4. Copy the key (starts with sk-...)"
        fi
    else
        MODEL_PROVIDER="anthropic"
        if [ "$LANG" = "lt" ]; then
            echo -e "  ${BOLD}Du būdai prisijungti prie Claude:${NC}"
            echo ""
            echo -e "  ${CYAN}A)${NC} ${BOLD}Claude Max/Pro prenumerata${NC} (rekomenduojama)"
            echo "     Jei turite Claude Pro (\$20/mėn) arba Max (\$100-200/mėn):"
            echo "     1. Įdiekite Claude CLI: ${CYAN}npm install -g @anthropic-ai/claude-code${NC}"
            echo "     2. Prisijunkite: ${CYAN}claude login${NC}"
            echo "     3. Gaukite token: ${CYAN}claude setup-token${NC}"
            echo ""
            echo -e "  ${CYAN}B)${NC} ${BOLD}Anthropic API raktas${NC} (mokėjimas už naudojimą)"
            echo "     1. Eikite į: ${CYAN}https://console.anthropic.com/settings/keys${NC}"
            echo "     2. Sukurkite naują API raktą"
        else
            echo -e "  ${BOLD}Two ways to connect Claude:${NC}"
            echo ""
            echo -e "  ${CYAN}A)${NC} ${BOLD}Claude Max/Pro subscription${NC} (recommended)"
            echo "     If you have Claude Pro (\$20/mo) or Max (\$100-200/mo):"
            echo "     1. Install Claude CLI: ${CYAN}npm install -g @anthropic-ai/claude-code${NC}"
            echo "     2. Log in: ${CYAN}claude login${NC}"
            echo "     3. Get token: ${CYAN}claude setup-token${NC}"
            echo ""
            echo -e "  ${CYAN}B)${NC} ${BOLD}Anthropic API key${NC} (pay-per-token)"
            echo "     1. Go to: ${CYAN}https://console.anthropic.com/settings/keys${NC}"
            echo "     2. Create a new API key"
        fi
    fi
    
    echo ""
    print_ask "${STR_PASTE_KEY}"
    read -rs API_KEY
    echo ""
    
    if [ -z "$API_KEY" ]; then
        print_error "${STR_NO_KEY}"
        exit 1
    fi
    
    # Detect setup-token vs API key
    if echo "$API_KEY" | grep -q "^sk-ant-"; then
        AUTH_MODE="api-key"
    else
        AUTH_MODE="setup-token"
    fi
    
    print_step "${STR_KEY_OK}"
}

# ============================================================
# AGE GROUP
# ============================================================
select_age_group() {
    echo ""
    echo -e "  ${BOLD}${STR_AGE_GROUP}${NC}"
    echo ""
    echo "  1. ${STR_AGE_1}"
    echo "  2. ${STR_AGE_2}"
    echo "  3. ${STR_AGE_3}"
    echo ""
    print_ask "Choose (1-3): "
    read -r AGE_CHOICE
    AGE_CHOICE="${AGE_CHOICE:-1}"
    
    case "$AGE_CHOICE" in
        1) AGE_GROUP="primary (6-10)"; AGE_GROUP_LT="pradinė mokykla (6-10 m.)" ;;
        2) AGE_GROUP="middle school (11-14)"; AGE_GROUP_LT="pagrindinė mokykla (11-14 m.)" ;;
        3) AGE_GROUP="high school (15-18)"; AGE_GROUP_LT="vidurinė mokykla (15-18 m.)" ;;
        *) AGE_GROUP="primary (6-10)"; AGE_GROUP_LT="pradinė mokykla (6-10 m.)" ;;
    esac
    
    if [ "$LANG" = "lt" ]; then
        print_step "Amžiaus grupė: ${AGE_GROUP_LT}"
    else
        print_step "Age group: ${AGE_GROUP}"
    fi
}

# ============================================================
# STUDENT NAMES INPUT
# ============================================================
input_students() {
    echo ""
    echo -e "  ${BOLD}${STR_STUDENTS}${NC}"
    echo ""
    echo -e "  ${STR_STUDENTS_ASK}"
    echo ""
    print_ask "${STR_STUDENTS_PROMPT}"
    echo ""
    
    # Read multi-line input until empty line
    NAMES_RAW=""
    while IFS= read -r line; do
        [ -z "$line" ] && break
        NAMES_RAW="${NAMES_RAW} ${line}"
    done
    
    # Parse names: split by comma, newline, or multiple spaces; trim; sort
    STUDENT_NAMES=()
    while IFS= read -r name; do
        name=$(echo "$name" | xargs)  # trim whitespace
        [ -n "$name" ] && STUDENT_NAMES+=("$name")
    done < <(echo "$NAMES_RAW" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | sort -f | uniq)
    
    NUM_STUDENTS=${#STUDENT_NAMES[@]}
    
    if [ "$NUM_STUDENTS" -eq 0 ]; then
        print_error "No student names entered!"
        exit 1
    fi
    
    echo ""
    print_step "${NUM_STUDENTS} ${STR_STUDENTS_CONFIRM}:"
    echo ""
    for i in "${!STUDENT_NAMES[@]}"; do
        echo "    $((i+1)). ${STUDENT_NAMES[$i]}"
    done
    echo ""
}

# ============================================================
# CREATE STUDENT AGENTS
# ============================================================
create_student_agents() {
    echo ""
    echo -e "  ${BOLD}${STR_CREATING}${NC}"
    echo ""
    
    OPENCLAW_DIR="$HOME/.openclaw"
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    TODAY=$(date +%Y-%m-%d)
    STUDENT_LIST=""
    
    for name in "${STUDENT_NAMES[@]}"; do
        # Create safe agent ID from name
        agent_id=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//;s/-$//')
        agent_dir="$OPENCLAW_DIR/agents/${agent_id}/workspace"
        
        mkdir -p "$agent_dir/memory"
        
        # Generate SOUL.md from template
        sed -e "s/{{STUDENT_NAME}}/${name}/g" \
            -e "s/{{AGE_GROUP}}/${AGE_GROUP}/g" \
            -e "s|{{LANGUAGE_INSTRUCTION}}|${LANG_INSTRUCTION}|g" \
            "$SCRIPT_DIR/agents/_kid-template/workspace/SOUL.md" > "$agent_dir/SOUL.md"
        
        # Generate MEMORY.md from template
        sed -e "s/{{STUDENT_NAME}}/${name}/g" \
            -e "s/{{AGE_GROUP}}/${AGE_GROUP}/g" \
            -e "s/{{DATE}}/${TODAY}/g" \
            "$SCRIPT_DIR/agents/_kid-template/workspace/MEMORY.md" > "$agent_dir/MEMORY.md"
        
        STUDENT_LIST="${STUDENT_LIST}\n- **${name}** → agent: ${agent_id}"
        
        echo -e "    ✅ ${name} (${agent_id})"
    done
    
    # Deploy teacher-assistant
    teacher_dir="$OPENCLAW_DIR/agents/teacher-assistant/workspace"
    mkdir -p "$teacher_dir/memory"
    
    # Build student roster for teacher
    ROSTER=""
    for name in "${STUDENT_NAMES[@]}"; do
        agent_id=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//;s/-$//')
        ROSTER="${ROSTER}- **${name}** (agent: ${agent_id})\n"
    done
    
    sed -e "s|{{LANGUAGE_INSTRUCTION}}|${LANG_INSTRUCTION}|g" \
        -e "s|{{REGION}}|${REGION}|g" \
        -e "s|{{STUDENT_LIST}}|${ROSTER}|g" \
        -e "s|{{AGE_GROUP}}|${AGE_GROUP}|g" \
        "$SCRIPT_DIR/agents/teacher-assistant/workspace/SOUL.md" > "$teacher_dir/SOUL.md"
    
    sed -e "s|{{CLASS_INFO}}|Age group: ${AGE_GROUP}, ${NUM_STUDENTS} students, Language: ${LANG}|g" \
        -e "s|{{STUDENT_LIST}}|${ROSTER}|g" \
        "$SCRIPT_DIR/agents/teacher-assistant/workspace/MEMORY.md" > "$teacher_dir/MEMORY.md"
    
    echo ""
    print_step "Teacher Assistant + ${NUM_STUDENTS} student agents created!"
}

# ============================================================
# GENERATE OPENCLAW CONFIG
# ============================================================
generate_config() {
    OPENCLAW_DIR="$HOME/.openclaw"
    mkdir -p "$OPENCLAW_DIR"
    
    # Build agents JSON
    AGENTS_JSON="\"teacher-assistant\": { \"name\": \"Teacher Assistant\", \"model\": \"anthropic/claude-sonnet-4-20250514\" }"
    
    for name in "${STUDENT_NAMES[@]}"; do
        agent_id=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//;s/-$//')
        AGENTS_JSON="${AGENTS_JSON},
        \"${agent_id}\": { \"name\": \"${name}\", \"model\": \"anthropic/claude-sonnet-4-20250514\" }"
    done
    
    # Detect timezone
    if command -v timedatectl &>/dev/null; then
        TIMEZONE=$(timedatectl show -p Timezone --value 2>/dev/null || echo "UTC")
    elif [ -f /etc/timezone ]; then
        TIMEZONE=$(cat /etc/timezone)
    else
        TIMEZONE="UTC"
    fi
    
    cat > "$OPENCLAW_DIR/openclaw.json" << CFGEOF
{
    "version": "1.0",
    "timezone": "${TIMEZONE}",
    "agents": {
        ${AGENTS_JSON}
    },
    "gateway": {
        "port": 18789
    }
}
CFGEOF
    
    # Store API key
    ENVFILE="$OPENCLAW_DIR/.env"
    if [ "$MODEL_PROVIDER" = "openai" ]; then
        echo "OPENAI_API_KEY=${API_KEY}" > "$ENVFILE"
    else
        echo "ANTHROPIC_API_KEY=${API_KEY}" > "$ENVFILE"
    fi
    chmod 600 "$ENVFILE"
    
    print_step "Configuration generated"
}

# ============================================================
# CREATE AGENT FOLDER
# ============================================================
create_agent_folder() {
    AGENT_FOLDER="$HOME/Agent Folder"
    OPENCLAW_DIR="$HOME/.openclaw"
    mkdir -p "$AGENT_FOLDER"
    
    # Link teacher assistant
    ln -sfn "$OPENCLAW_DIR/agents/teacher-assistant/workspace" "$AGENT_FOLDER/Teacher Assistant"
    
    # Link each student
    for name in "${STUDENT_NAMES[@]}"; do
        agent_id=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//;s/-$//')
        ln -sfn "$OPENCLAW_DIR/agents/${agent_id}/workspace" "$AGENT_FOLDER/${name}"
    done
    
    if [ "$LANG" = "lt" ]; then
        README_CONTENT="=== 🎓 Class Assistant — Agentų aplankas ===

Šiame aplanke rasite visų AI agentų darbo sritis.

📁 Teacher Assistant/  — Pagrindinis mokytojo asistentas
"
    else
        README_CONTENT="=== 🎓 Class Assistant — Agent Folder ===

This folder contains all AI agent workspaces.

📁 Teacher Assistant/  — Main teaching assistant
"
    fi
    
    for name in "${STUDENT_NAMES[@]}"; do
        README_CONTENT="${README_CONTENT}📁 ${name}/  — Student agent\n"
    done
    
    README_CONTENT="${README_CONTENT}
HOW TO CUSTOMIZE:
- Edit SOUL.md to change agent personality
- Edit MEMORY.md to add notes about a student
- Check memory/ folder for interaction logs

${STR_PRIVACY}
"
    echo -e "$README_CONTENT" > "$AGENT_FOLDER/README.txt"
    
    print_step "Agent Folder: ~/Agent Folder"
}

# ============================================================
# SETUP SAMBA
# ============================================================
setup_samba() {
    AGENT_FOLDER="$HOME/Agent Folder"
    
    case "$OS" in
        rpi|linux|wsl)
            if ! dpkg -l samba &>/dev/null 2>&1; then
                sudo apt-get install -y samba samba-common 2>/dev/null || return
            fi
            
            SAMBA_CONF="/etc/samba/smb.conf"
            if ! grep -q "Agent Folder" "$SAMBA_CONF" 2>/dev/null; then
                sudo tee -a "$SAMBA_CONF" > /dev/null << SAMBAEOF

[Agent Folder]
   comment = Class Assistant Agent Workspaces
   path = ${AGENT_FOLDER}
   browseable = yes
   read only = no
   guest ok = no
   valid users = $(whoami)
   create mask = 0644
   directory mask = 0755
SAMBAEOF
                sudo smbpasswd -a "$(whoami)" 2>/dev/null || true
                sudo systemctl restart smbd 2>/dev/null || true
                sudo systemctl enable smbd 2>/dev/null || true
            fi
            
            LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
            [ -n "$LOCAL_IP" ] && print_step "Network: \\\\${LOCAL_IP}\\Agent Folder"
            ;;
    esac
}

# ============================================================
# SETUP AUTO-START
# ============================================================
setup_autostart() {
    case "$OS" in
        rpi|linux)
            sudo tee /etc/systemd/system/openclaw.service > /dev/null << SVCEOF
[Unit]
Description=Class Assistant AI Gateway
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$HOME
ExecStart=$(which openclaw) gateway
Restart=on-failure
RestartSec=10
Environment=HOME=$HOME
Environment=PATH=$(echo $PATH)

[Install]
WantedBy=multi-user.target
SVCEOF
            sudo systemctl daemon-reload
            sudo systemctl enable openclaw.service
            print_step "Auto-start enabled"
            ;;
        macos)
            PLIST_DIR="$HOME/Library/LaunchAgents"
            mkdir -p "$PLIST_DIR"
            cat > "$PLIST_DIR/com.classassistant.gateway.plist" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.classassistant.gateway</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProgramArguments</key>
  <array><string>$(which openclaw)</string><string>gateway</string></array>
</dict>
</plist>
PLISTEOF
            launchctl bootstrap "gui/$(id -u)" "$PLIST_DIR/com.classassistant.gateway.plist" 2>/dev/null || true
            print_step "Auto-start enabled"
            ;;
    esac
}

# ============================================================
# SETUP DESKTOP SHORTCUT + WEB UI
# ============================================================
setup_webchat() {
    GW_PORT="18789"
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    LOCAL_IP="${LOCAL_IP:-localhost}"
    
    case "$OS" in
        rpi|linux|wsl)
            DESKTOP_DIR="$HOME/Desktop"
            mkdir -p "$DESKTOP_DIR" 2>/dev/null || true
            cat > "$DESKTOP_DIR/Class Assistant.desktop" << DSKEOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Class Assistant
Comment=AI Teaching Assistant
Icon=web-browser
Exec=xdg-open http://${LOCAL_IP}:${GW_PORT}
Terminal=false
Categories=Education;
DSKEOF
            chmod +x "$DESKTOP_DIR/Class Assistant.desktop" 2>/dev/null || true
            ;;
        macos)
            cat > "$HOME/Desktop/Class Assistant.command" << MACEOF
#!/usr/bin/env bash
open "http://localhost:${GW_PORT}"
MACEOF
            chmod +x "$HOME/Desktop/Class Assistant.command"
            ;;
    esac
    
    # Also in Agent Folder
    AGENT_FOLDER="$HOME/Agent Folder"
    cat > "$AGENT_FOLDER/Open Chat.sh" << LAUNCHEOF
#!/usr/bin/env bash
URL="http://${LOCAL_IP}:${GW_PORT}"
if command -v xdg-open &>/dev/null; then xdg-open "\$URL"
elif command -v open &>/dev/null; then open "\$URL"
else echo "Open: \$URL"
fi
LAUNCHEOF
    chmod +x "$AGENT_FOLDER/Open Chat.sh"
    
    print_step "Desktop shortcut: Class Assistant"
}

# ============================================================
# DISCORD AUTO-SETUP
# ============================================================
setup_discord() {
    echo ""
    if [ "$LANG" = "lt" ]; then
        echo -e "  ${BOLD}━━━ 🎮 Discord kanalų kūrimas (neprivaloma) ━━━${NC}"
        echo ""
        echo "  Discord leidžia kiekvienam mokiniui turėti atskirą kanalą."
        echo "  Mokytojas rašo #Jonas kanale — atsako Jono agentas."
        echo ""
        print_ask "Norite sukurti Discord kanalus? (t/n) [n]: "
    else
        echo -e "  ${BOLD}━━━ 🎮 Discord Channel Setup (optional) ━━━${NC}"
        echo ""
        echo "  Discord lets each student have their own channel."
        echo "  Write in #Jonas channel — Jonas's agent responds."
        echo ""
        print_ask "Set up Discord channels? (y/n) [n]: "
    fi
    read -r WANT_DISCORD
    
    if [[ ! "$WANT_DISCORD" =~ ^[YyTt] ]]; then
        return
    fi
    
    echo ""
    if [ "$LANG" = "lt" ]; then
        echo -e "  ${BOLD}1 žingsnis:${NC} Sukurkite Discord serverį"
        echo "  Atidarykite Discord → spauskite ${BOLD}+${NC} → Create My Own"
        echo "  Pavadinimas: ${CYAN}Mano Klasė${NC}"
        echo ""
        print_ask "Spauskite Enter kai serveris sukurtas... "
    else
        echo -e "  ${BOLD}Step 1:${NC} Create a Discord server"
        echo "  Open Discord → click ${BOLD}+${NC} → Create My Own"
        echo "  Name: ${CYAN}My Class${NC}"
        echo ""
        print_ask "Press Enter when server is created... "
    fi
    read -r
    
    echo ""
    if [ "$LANG" = "lt" ]; then
        echo -e "  ${BOLD}2 žingsnis:${NC} Sukurkite Discord botą"
        echo "  Atidarykite: ${CYAN}https://discord.com/developers/applications${NC}"
        echo "  1. Spauskite ${BOLD}New Application${NC} → pavadinkite 'Class Assistant'"
        echo "  2. Eikite į ${BOLD}Bot${NC} meniu"
        echo "  3. Spauskite ${BOLD}Reset Token${NC} → nukopijuokite"
        echo "  4. Įjunkite ${BOLD}Message Content Intent${NC}"
        echo "  5. Spauskite ${BOLD}Save Changes${NC}"
        echo ""
        print_ask "Įklijuokite Discord bot token: "
    else
        echo -e "  ${BOLD}Step 2:${NC} Create a Discord bot"
        echo "  Open: ${CYAN}https://discord.com/developers/applications${NC}"
        echo "  1. Click ${BOLD}New Application${NC} → name it 'Class Assistant'"
        echo "  2. Go to ${BOLD}Bot${NC} menu"
        echo "  3. Click ${BOLD}Reset Token${NC} → copy it"
        echo "  4. Enable ${BOLD}Message Content Intent${NC}"
        echo "  5. Click ${BOLD}Save Changes${NC}"
        echo ""
        print_ask "Paste Discord bot token: "
    fi
    read -r DC_TOKEN
    
    [ -z "$DC_TOKEN" ] && return
    
    echo ""
    if [ "$LANG" = "lt" ]; then
        echo -e "  ${BOLD}3 žingsnis:${NC} Pakvieskite botą į serverį"
        echo "  Developer portale: ${BOLD}OAuth2 → URL Generator${NC}"
        echo "  Pažymėkite: ${CYAN}bot${NC}, ${CYAN}applications.commands${NC}"
        echo "  Leidimai: ${CYAN}Send Messages, Read History, Manage Channels${NC}"
        echo "  Nukopijuokite URL → atidarykite → pasirinkite serverį"
        echo ""
        print_ask "Spauskite Enter kai botas serveryje... "
    else
        echo -e "  ${BOLD}Step 3:${NC} Invite bot to server"
        echo "  In Developer Portal: ${BOLD}OAuth2 → URL Generator${NC}"
        echo "  Check: ${CYAN}bot${NC}, ${CYAN}applications.commands${NC}"
        echo "  Permissions: ${CYAN}Send Messages, Read History, Manage Channels${NC}"
        echo "  Copy URL → open it → select your server"
        echo ""
        print_ask "Press Enter when bot is in server... "
    fi
    read -r
    
    echo ""
    if [ "$LANG" = "lt" ]; then
        echo "  Įjunkite Developer Mode: Settings → Advanced → Developer Mode"
        echo "  Dešiniu pelės mygtuku ant serverio pavadinimo → ${BOLD}Copy Server ID${NC}"
        echo ""
        print_ask "Įklijuokite serverio ID: "
    else
        echo "  Enable Developer Mode: Settings → Advanced → Developer Mode"
        echo "  Right-click server name → ${BOLD}Copy Server ID${NC}"
        echo ""
        print_ask "Paste server ID: "
    fi
    read -r GUILD_ID
    
    [ -z "$GUILD_ID" ] && return
    
    echo ""
    print_info "${STR_CREATING}"
    echo ""
    
    # Create category
    CATEGORY_ID=$(curl -s -X POST \
        "https://discord.com/api/v10/guilds/${GUILD_ID}/channels" \
        -H "Authorization: Bot ${DC_TOKEN}" \
        -H "Content-Type: application/json" \
        -d '{"name": "Class Assistant", "type": 4}' \
        2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
    
    # Create teacher channel
    TEACHER_CH=$(curl -s -X POST \
        "https://discord.com/api/v10/guilds/${GUILD_ID}/channels" \
        -H "Authorization: Bot ${DC_TOKEN}" \
        -H "Content-Type: application/json" \
        -d "{\"name\": \"teacher-assistant\", \"type\": 0, \"parent_id\": \"${CATEGORY_ID}\", \"topic\": \"Main teaching assistant\"}" \
        2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
    
    [ -n "$TEACHER_CH" ] && [ "$TEACHER_CH" != "None" ] && {
        openclaw config set "channels.discord.groups.${TEACHER_CH}.agentId" "teacher-assistant" 2>/dev/null || true
        echo "    ✅ #teacher-assistant"
    }
    
    # Create student channels
    for name in "${STUDENT_NAMES[@]}"; do
        agent_id=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//;s/-$//')
        
        CH_ID=$(curl -s -X POST \
            "https://discord.com/api/v10/guilds/${GUILD_ID}/channels" \
            -H "Authorization: Bot ${DC_TOKEN}" \
            -H "Content-Type: application/json" \
            -d "{\"name\": \"${agent_id}\", \"type\": 0, \"parent_id\": \"${CATEGORY_ID}\", \"topic\": \"${name} - Student Agent\"}" \
            2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
        
        [ -n "$CH_ID" ] && [ "$CH_ID" != "None" ] && {
            openclaw config set "channels.discord.groups.${CH_ID}.agentId" "${agent_id}" 2>/dev/null || true
            echo "    ✅ #${agent_id} → ${name}"
        }
    done
    
    openclaw config set channels.discord.token "$DC_TOKEN" 2>/dev/null || true
    echo ""
    print_step "Discord channels created and configured!"
}

# ============================================================
# MAIN
# ============================================================
main() {
    print_banner
    detect_platform
    check_license
    select_language
    configure_cloud
    
    echo ""
    echo -e "  ${BOLD}${STR_SIT_BACK}${NC}"
    echo ""
    
    select_age_group
    input_students
    
    ensure_nodejs
    ensure_openclaw
    create_student_agents
    generate_config
    create_agent_folder
    setup_samba
    setup_autostart
    setup_webchat
    setup_discord
    
    # Start and open
    echo ""
    echo -e "${CYAN}"
    echo "  ╔══════════════════════════════════════════════╗"
    echo "  ║  🎉 ${STR_DONE}                              ║"
    echo "  ╚══════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "  ${BOLD}${STR_PRIVACY}${NC}"
    echo ""
    echo "    🎓 Teacher Assistant + ${NUM_STUDENTS} student agents"
    echo "    📁 ~/Agent Folder"
    echo "    🚀 Auto-starts on boot"
    echo ""
    
    openclaw gateway start 2>/dev/null &
    sleep 2
    
    GW_PORT="18789"
    if [ "$OS" = "macos" ]; then
        open "http://localhost:${GW_PORT}" 2>/dev/null || true
    elif command -v xdg-open &>/dev/null; then
        xdg-open "http://localhost:${GW_PORT}" 2>/dev/null || true
    fi
    
    echo -e "  💬 ${BOLD}${STR_CHAT_OPEN}${NC}"
    echo -e "     ${CYAN}http://localhost:${GW_PORT}${NC}"
    echo ""
    echo "  👋 Say hi to your new teaching assistant!"
    echo ""
}

main "$@"
