# Teacher Assistant Memory

## Class Information
{{CLASS_INFO}}

## Student Roster
{{STUDENT_LIST}}

## Observations & Notes
(This section will grow as the teacher works with the assistant)

## Task History
(Tasks created and their outcomes will be logged here)
