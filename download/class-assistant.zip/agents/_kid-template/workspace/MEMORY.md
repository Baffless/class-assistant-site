# {{STUDENT_NAME}} — Student Profile

## Basic Info
- **Name**: {{STUDENT_NAME}}
- **Age Group**: {{AGE_GROUP}}
- **Date Added**: {{DATE}}

## Academic Strengths
(Will be discovered and updated over time)

## Academic Weaknesses
(Will be discovered and updated over time)

## Learning Style
(Will be identified through interactions)

## Behavior Notes
(Teacher observations logged here)

## Task Performance
(Results and progress tracked here)

## Special Notes
(Any additional information from the teacher)
